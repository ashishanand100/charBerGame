# charBerGame
Online Play Game Link - https://pawansaini020.github.io/CharBerGame/

Tools and language:
1. Javascript
2. CSS
3. HTML

# How to play
1. In the game you are given a 3x3 grid.
2. The player who is playing "X" always goes first. Players alternate placing 'X's and 'O's on the board till 3 moves each.
3. Then players alternate can move its position to the neighbour box till winner.
4. For win the game, you have to place your all 3 'X' or 'O' in a straight or diagnol line.


You are welcome for any open contribution or any queries.
1. Github Id: @pawansaini020
2. Email Id: ps21@iitbbs.ac.in
